module.exports = {
    entry: "./src/core/index.js",
    output: {
        filename: "bundle.js"
    },
    mode: 'development'
}